<?php
define("MadMan",true);
require_once("inc/init.php");
$smarty->display("about.html");
?>