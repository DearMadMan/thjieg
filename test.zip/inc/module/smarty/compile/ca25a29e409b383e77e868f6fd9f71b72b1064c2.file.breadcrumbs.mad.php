<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 12:43:58
         compiled from "E:\apache\www\test\mdadmin\template\breadcrumbs.mad" */ ?>
<?php /*%%SmartyHeaderCode:10354535c8b0e7dc080-05876932%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca25a29e409b383e77e868f6fd9f71b72b1064c2' => 
    array (
      0 => 'E:\\apache\\www\\test\\mdadmin\\template\\breadcrumbs.mad',
      1 => 1394435124,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10354535c8b0e7dc080-05876932',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535c8b0e7ded66_77903371',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535c8b0e7ded66_77903371')) {function content_535c8b0e7ded66_77903371($_smarty_tpl) {?><!--breadcrumbs-->

      <div id="breadcrumb">
      <a href="index.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
      <a href="#">Sample pages</a> 
      <a href="#" class="current">Error</a> 
      </div>
<!--End-breadcrumbs--><?php }} ?>
