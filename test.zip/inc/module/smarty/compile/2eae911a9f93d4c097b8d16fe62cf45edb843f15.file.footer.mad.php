<?php /* Smarty version Smarty-3.1.16, created on 2014-01-02 10:08:33
         compiled from "E:\apache\www\my\admin\template\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:563452c4ca21caea66-40171610%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2eae911a9f93d4c097b8d16fe62cf45edb843f15' => 
    array (
      0 => 'E:\\apache\\www\\my\\admin\\template\\footer.mad',
      1 => 1388627186,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '563452c4ca21caea66-40171610',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52c4ca21caf5e6_05387759',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52c4ca21caf5e6_05387759')) {function content_52c4ca21caf5e6_05387759($_smarty_tpl) {?><?php }} ?>
