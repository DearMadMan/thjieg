<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 17:07:39
         compiled from "D:\wamp\www\test\view\default\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:12605535cc8dbd18d62-93068470%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fde8d4571f0fb10c76f9cadc8de7c7a00573c6db' => 
    array (
      0 => 'D:\\wamp\\www\\test\\view\\default\\footer.html',
      1 => 1398586773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12605535cc8dbd18d62-93068470',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535cc8dbd1cbe9_16766790',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535cc8dbd1cbe9_16766790')) {function content_535cc8dbd1cbe9_16766790($_smarty_tpl) {?>

    <div class="container">

        <hr>

        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Company 2013</p>
                </div>
            </div>
        </footer>

    </div>
<?php }} ?>
