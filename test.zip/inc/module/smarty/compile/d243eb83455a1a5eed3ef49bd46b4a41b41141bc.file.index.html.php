<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 17:07:39
         compiled from "D:\wamp\www\test\view\default\index.html" */ ?>
<?php /*%%SmartyHeaderCode:22247535cc8dbba9a05-04833532%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd243eb83455a1a5eed3ef49bd46b4a41b41141bc' => 
    array (
      0 => 'D:\\wamp\\www\\test\\view\\default\\index.html',
      1 => 1398586774,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22247535cc8dbba9a05-04833532',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'vp' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535cc8dbcf1c59_43187615',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535cc8dbcf1c59_43187615')) {function content_535cc8dbcf1c59_43187615($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>关于我们 - 太和县桔梗产业集群技术服务中心</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/css/modern-business.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/font-awesome/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

    <?php echo $_smarty_tpl->getSubTemplate ("header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



    <div class="container">

        <div class="row">

            <div class="col-lg-12">
                <h1 class="page-header">关于我们
                    <small>It's Nice to Meet You!</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a>
                    </li>
                    <li class="active">About</li>
                </ol>
            </div>

        </div>

        <div class="row">

            <div class="col-md-6">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/2.jpg">
            </div>
            <div class="col-md-6">
                <h2>欢迎来到太和县桔梗产业集群技术服务中心</h2>
                <p>太和县桔梗产业集群技术服务中心成立于2009年，民办非企业性质。中心现有办公用房2000平方米，各类服务器、办公电脑、仪器设备100多台套，工作人员42人，其中大专及中级以上专业职称人员32人。 中心自成立以来，致力于太和桔梗产业集群服务平台建设，围绕“促进信息化与工业化融合，走新型工业化道路”的发展战略，积极开展面向全县及周边地区桔梗及农副产品加工企业的产品检验检测、生产技术培训及信息咨询等全方位的服务；积极推进科研与生产之间的技术协作与联合；促进中小企业的技术进步，为振兴太和经济服务.</p>
                <p>本单位自2009年成立以来，一直遵守信义第一，客户至上的原则，我单位位于太和县西北部，与河南省、安徽省界首市三县市交界处，漯阜铁路，京九铁路，105国道外加两条高速公路横穿我县，交通十分便利，我单位生产的桔梗丝，脱水罗卜条，地瓜腾，速冻桔梗丝及桔梗段等地产中药材主要出口韩国、美国及东南亚各国，由于质量较好，长期以来深受客户好评，欢迎新老客户来电来人联系。</p>
            </div>

        </div>

        <!-- Team Member Profiles -->

        <div class="row">

            <div class="col-lg-12">
                <h2 class="page-header">Our Team</h2>
            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/3.jpg" height="450" width="600">
                <h3>工作车间
                    <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/4.jpg">
                <h3>工作车间
                     <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/5.jpg">
                <h3>工作车间
                      <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/6.jpg">
                <h3>工作车间
                      <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/7.jpg">
                <h3>工作车间
                    <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/8.jpg">
                <h3>工作车间
                    <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

        </div>

        <!-- Our Customers -->

        <div class="row">

            <div class="col-lg-12">
                <h2 class="page-header">Our Customers</h2>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

        </div>

    </div>


<?php echo $_smarty_tpl->getSubTemplate ("footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <!-- JavaScript -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/js/jquery-1.10.2.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/js/bootstrap.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/js/modern-business.js"></script>

</body>

</html>
<?php }} ?>
