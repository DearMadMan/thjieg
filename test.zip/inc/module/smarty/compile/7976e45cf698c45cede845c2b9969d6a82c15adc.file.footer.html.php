<?php /* Smarty version Smarty-3.1.16, created on 2014-04-28 08:37:26
         compiled from "E:\apache\www\test\view\default\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:10779535c83e1a41b73-09186716%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7976e45cf698c45cede845c2b9969d6a82c15adc' => 
    array (
      0 => 'E:\\apache\\www\\test\\view\\default\\footer.html',
      1 => 1398572630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10779535c83e1a41b73-09186716',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535c83e1a43f92_67408962',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535c83e1a43f92_67408962')) {function content_535c83e1a43f92_67408962($_smarty_tpl) {?>

    <div class="container">

        <hr>

        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Company 2013</p>
                </div>
            </div>
        </footer>

    </div>
<?php }} ?>
