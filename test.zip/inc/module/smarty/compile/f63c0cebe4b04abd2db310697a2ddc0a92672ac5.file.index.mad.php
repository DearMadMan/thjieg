<?php /* Smarty version Smarty-3.1.16, created on 2014-03-06 14:41:40
         compiled from "E:\apache\www\my\view\default\index.mad" */ ?>
<?php /*%%SmartyHeaderCode:1326052b3fcfcdde949-91742039%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f63c0cebe4b04abd2db310697a2ddc0a92672ac5' => 
    array (
      0 => 'E:\\apache\\www\\my\\view\\default\\index.mad',
      1 => 1394085120,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1326052b3fcfcdde949-91742039',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52b3fcfce32c79_45554256',
  'variables' => 
  array (
    'vp' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52b3fcfce32c79_45554256')) {function content_52b3fcfce32c79_45554256($_smarty_tpl) {?><!DOCTYPE html><!--HTML5 doctype-->
<html>
<head>
	<title>Your New Application</title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/css/sytle.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/css/pure-min.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/plugins/font-awesome-4.0.3/css/font-awesome.min.css">
	<script src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/js/jquery-1.9.0.js"></script>
	<script src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/js/index.js"></script>
</head>
<body>
	<!-- content goes here-->
	<header class="header">
	<div class="logo">
	    <img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/logo.png" alt="logo">
	</div>
	<div class="content">
	     <div class="search">
	      <form id="search-form" action="search.php" method="POST">
	           <input type="name" id="search" name="search" placeholder="雅诗兰黛"><a href="javascript:;"><i class="fa fa-search white"></i></a>
	      </form>
	     </div>
	</div>
	</header>
	<section class="ad-nav">
	    <ul class="ul">
	        <li><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/ad-nav.jpg" alt=""></a></li>
	    </ul>
	</section>
	<section class="pic-categroy">
	    <ul >
	        <li><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy_1.jpg" alt=""></a></li>
	        <li><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy_2.jpg" alt=""></a></li>
	        <li><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy_3.jpg" alt=""></a></li>
	        <li><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy_4.jpg" alt=""></a></li>
	    </ul>
	</section>
	<section class="ad-img">
	    <div class="imgl"><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/ad-img1.jpg" alt="1"><p>雅顿1折起</p></a></div>
	    <div class="imgr"><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/ad-img2.jpg" alt="1"><p>雅顿1折起</p></a></div>
	    <article class="categroy-list">
	        <ul>
	            <li><a href="#">思亲肤</a></li>
	            <li><a href="#">菲诗小铺</a></li>
	            <li><a href="#">雅诗兰黛</a></li>
	            <li><a href="#">兰蔻</a></li>
	            <li><a href="#">倩碧</a></li>
	            <li><a href="#">兰芝</a></li>
	            <li><a href="#">雅漾</a></li>
	            <li><a href="#">欧莱雅</a></li>
	        </ul>
	    </article>

	</section>

	<section class="goods-category wrap">
	    <article class="category-info">
	        <ul class="ul-2 wrap">
	            <li class="first bg-color-1"><a href="#"><h1>护肤</h1><h3>Skin Care</h3></a></li>
	            <li class="last"><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy-info-1.jpg" alt="#"><p>保湿秘籍</p></a></li>
	        </ul>
	    </article>

	     <article class="categroy-list">
	        <ul>
	            <li><a href="#">洁面</a></li>
	            <li><a href="#">面膜</a></li>
	            <li><a href="#">乳液</a></li>
	            <li><a href="#">护肤套装</a></li>
	        </ul>
	    </article>

	    <article class="article-list wrap">
            <ul class="ul-2 wrap">
                <li><a href="#">【5折】倩碧润肤露125ml ￥198</a></li>
                <li><a href="#">【4折】兰芝毛孔紧致洗面奶 ￥89.9</a></li>
                <li><a href="#">【3折】兰蔻小黑瓶三支装 ￥188</a></li>
                <li><a href="#">【2折】兰蔻礼包 ￥275</a></li>
            </ul>
        </article>
	</section>



	<section class="goods-category wrap">
	    <article class="category-info">
	        <ul class="ul-2 wrap">
	            <li class="last"><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy-info-1.jpg" alt="#"><p>保湿秘籍</p></a></li>
	            <li class="first bg-color-1"><a href="#"><h1>护肤</h1><h3>Skin Care</h3></a></li>

	        </ul>
	    </article>

	     <article class="categroy-list">
	        <ul>
	            <li><a href="#">洁面</a></li>
	            <li><a href="#">面膜</a></li>
	            <li><a href="#">乳液</a></li>
	            <li><a href="#">护肤套装</a></li>
	        </ul>
	    </article>

	    <article class="article-list wrap">
            <ul class="ul-2 wrap">
                <li><a href="#">【5折】倩碧润肤露125ml ￥198</a></li>
                <li><a href="#">【4折】兰芝毛孔紧致洗面奶 ￥89.9</a></li>
                <li><a href="#">【3折】兰蔻小黑瓶三支装 ￥188</a></li>
                <li><a href="#">【2折】兰蔻礼包 ￥275</a></li>
            </ul>
        </article>
	</section>






	<section class="goods-category wrap">
	    <article class="category-info">
	        <ul class="ul-2 wrap">
	            <li class="first bg-color-1"><a href="#"><h1>护肤</h1><h3>Skin Care</h3></a></li>
	            <li class="last"><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy-info-1.jpg" alt="#"><p>保湿秘籍</p></a></li>
	        </ul>
	    </article>

	     <article class="categroy-list">
	        <ul>
	            <li><a href="#">洁面</a></li>
	            <li><a href="#">面膜</a></li>
	            <li><a href="#">乳液</a></li>
	            <li><a href="#">护肤套装</a></li>
	        </ul>
	    </article>

	    <article class="article-list wrap">
            <ul class="ul-2 wrap">
                <li><a href="#">【5折】倩碧润肤露125ml ￥198</a></li>
                <li><a href="#">【4折】兰芝毛孔紧致洗面奶 ￥89.9</a></li>
                <li><a href="#">【3折】兰蔻小黑瓶三支装 ￥188</a></li>
                <li><a href="#">【2折】兰蔻礼包 ￥275</a></li>
            </ul>
        </article>
	</section>





	<section class="goods-category wrap">
	    <article class="category-info">
	        <ul class="ul-2 wrap">
	               <li class="last"><a href="#"><img src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/categroy-info-1.jpg" alt="#"><p>保湿秘籍</p></a></li>
	            <li class="first bg-color-1"><a href="#"><h1>护肤</h1><h3>Skin Care</h3></a></li>

	        </ul>
	    </article>

	     <article class="categroy-list">
	        <ul>
	            <li><a href="#">洁面</a></li>
	            <li><a href="#">面膜</a></li>
	            <li><a href="#">乳液</a></li>
	            <li><a href="#">护肤套装</a></li>
	        </ul>
	    </article>

	    <article class="article-list wrap">
            <ul class="ul-2 wrap">
                <li><a href="#">【5折】倩碧润肤露125ml ￥198</a></li>
                <li><a href="#">【4折】兰芝毛孔紧致洗面奶 ￥89.9</a></li>
                <li><a href="#">【3折】兰蔻小黑瓶三支装 ￥188</a></li>
                <li><a href="#">【2折】兰蔻礼包 ￥275</a></li>
            </ul>
        </article>
	</section>


	   <section class="ad-img">
	    <article class="categroy-list">
	        <ul>
	            <li><a href="#">思亲肤</a></li>
	            <li><a href="#">菲诗小铺</a></li>
	            <li><a href="#">雅诗兰黛</a></li>
	            <li><a href="#">兰蔻</a></li>
	            <li><a href="#">倩碧</a></li>
	            <li><a href="#">兰芝</a></li>
	            <li><a href="#">雅漾</a></li>
	            <li><a href="#">欧莱雅</a></li>
	        </ul>
	    </article>

	</section>


	<?php echo $_smarty_tpl->getSubTemplate ("footer.mad", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>





</body>
</html>
<?php }} ?>
