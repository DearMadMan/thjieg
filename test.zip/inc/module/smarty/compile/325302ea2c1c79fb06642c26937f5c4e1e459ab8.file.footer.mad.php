<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 17:12:07
         compiled from "D:\wamp\www\test\mdadmin\template\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:3930535cc9e756d2a0-25662656%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '325302ea2c1c79fb06642c26937f5c4e1e459ab8' => 
    array (
      0 => 'D:\\wamp\\www\\test\\mdadmin\\template\\footer.mad',
      1 => 1398586772,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3930535cc9e756d2a0-25662656',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535cc9e7571127_23541128',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535cc9e7571127_23541128')) {function content_535cc9e7571127_23541128($_smarty_tpl) {?><!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; Matrix Admin. Brought to you by <a href="http://www.dearmadman.com/">dearmadn.com</a> </div>
</div>

<!--end-Footer-part--><?php }} ?>
