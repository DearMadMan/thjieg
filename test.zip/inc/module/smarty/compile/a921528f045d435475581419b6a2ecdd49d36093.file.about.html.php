<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 22:39:57
         compiled from "D:\wamp\www\test\view\default\about.html" */ ?>
<?php /*%%SmartyHeaderCode:1412535d16bd230215-87004222%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a921528f045d435475581419b6a2ecdd49d36093' => 
    array (
      0 => 'D:\\wamp\\www\\test\\view\\default\\about.html',
      1 => 1398586773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1412535d16bd230215-87004222',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535d16bd26aba2_22958031',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535d16bd26aba2_22958031')) {function content_535d16bd26aba2_22958031($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>关于我们 - 太和县桔梗产业集群技术服务中心</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/modern-business.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">太和县桔梗产业集群技术服务中心</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">

                    <li><a href="about.html">关于我们</a>
                    </li>
                    <li><a href="services.html">服务中心</a>
                    </li>
                       <li><a href="contact.php">文章中心</a>
                    </li>
                    <li><a href="contact.php">联系我们</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <div class="container">

        <div class="row">

            <div class="col-lg-12">
                <h1 class="page-header">关于我们
                    <small>It's Nice to Meet You!</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a>
                    </li>
                    <li class="active">About</li>
                </ol>
            </div>

        </div>

        <div class="row">

            <div class="col-md-6">
                <img class="img-responsive" src="images/2.jpg">
            </div>
            <div class="col-md-6">
                <h2>欢迎来到太和县桔梗产业集群技术服务中心</h2>
                <p>太和县桔梗产业集群技术服务中心成立于2009年，民办非企业性质。中心现有办公用房2000平方米，各类服务器、办公电脑、仪器设备100多台套，工作人员42人，其中大专及中级以上专业职称人员32人。 中心自成立以来，致力于太和桔梗产业集群服务平台建设，围绕“促进信息化与工业化融合，走新型工业化道路”的发展战略，积极开展面向全县及周边地区桔梗及农副产品加工企业的产品检验检测、生产技术培训及信息咨询等全方位的服务；积极推进科研与生产之间的技术协作与联合；促进中小企业的技术进步，为振兴太和经济服务.</p>
                <p>本单位自2009年成立以来，一直遵守信义第一，客户至上的原则，我单位位于太和县西北部，与河南省、安徽省界首市三县市交界处，漯阜铁路，京九铁路，105国道外加两条高速公路横穿我县，交通十分便利，我单位生产的桔梗丝，脱水罗卜条，地瓜腾，速冻桔梗丝及桔梗段等地产中药材主要出口韩国、美国及东南亚各国，由于质量较好，长期以来深受客户好评，欢迎新老客户来电来人联系。</p>
            </div>

        </div>

        <!-- Team Member Profiles -->

        <div class="row">

            <div class="col-lg-12">
                <h2 class="page-header">Our Team</h2>
            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="images/3.jpg" height="450" width="600">
                <h3>工作车间
                    <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="images/4.jpg">
                <h3>工作车间
                     <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="images/5.jpg">
                <h3>工作车间
                      <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="images/6.jpg">
                <h3>工作车间
                      <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="images/7.jpg">
                <h3>工作车间
                    <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

            <div class="col-sm-4">
                <img class="img-responsive" src="images/8.jpg">
                <h3>工作车间
                    <small>厂房一角</small>
                </h3>
                <p>我们的团队正在安全生产、保质保量完成生产任务
                </p>

            </div>

        </div>

        <!-- Our Customers -->

        <div class="row">

            <div class="col-lg-12">
                <h2 class="page-header">Our Customers</h2>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive img-customer" src="http://placehold.it/500x300">
            </div>

        </div>

    </div>
    <!-- /.container -->

    <div class="container">

        <hr>

        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Company 2013</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/modern-business.js"></script>

</body>

</html>
<?php }} ?>
