<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 17:12:07
         compiled from "D:\wamp\www\test\mdadmin\template\breadcrumbs.mad" */ ?>
<?php /*%%SmartyHeaderCode:21253535cc9e7555b99-71760469%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3dcbe6ad183dcf1beb45f0e1bed032c9d67b8f18' => 
    array (
      0 => 'D:\\wamp\\www\\test\\mdadmin\\template\\breadcrumbs.mad',
      1 => 1398586772,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21253535cc9e7555b99-71760469',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535cc9e7559a23_16180636',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535cc9e7559a23_16180636')) {function content_535cc9e7559a23_16180636($_smarty_tpl) {?><!--breadcrumbs-->

      <div id="breadcrumb">
      <a href="index.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
      <a href="#">Sample pages</a> 
      <a href="#" class="current">Error</a> 
      </div>
<!--End-breadcrumbs--><?php }} ?>
