<?php /* Smarty version Smarty-3.1.16, created on 2014-04-27 12:43:58
         compiled from "E:\apache\www\test\mdadmin\template\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:9411535c8b0e7f0e70-46552482%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '804c673644cbd4c84e5d9513d529901b893752a8' => 
    array (
      0 => 'E:\\apache\\www\\test\\mdadmin\\template\\footer.mad',
      1 => 1394432064,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9411535c8b0e7f0e70-46552482',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535c8b0e7f5148_53898381',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535c8b0e7f5148_53898381')) {function content_535c8b0e7f5148_53898381($_smarty_tpl) {?><!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; Matrix Admin. Brought to you by <a href="http://www.dearmadman.com/">dearmadn.com</a> </div>
</div>

<!--end-Footer-part--><?php }} ?>
